import copy
import pygame
import sys
from random import randint, choice

pygame.init()
size = 880, 660
screen = pygame.display.set_mode(size)
pygame.display.set_caption('tetris')
clock = pygame.time.Clock()
fps = 120
f = open("tetris_options.txt", encoding="utf8")
options = {}
for i in range(5):
    line = f.readline()
    options[line.split(':')[0]] = line.split(':')[1][:-1]
f.close()
bg_fil = [pygame.Color(0, 0, 0), pygame.Color(190, 190, 190), pygame.Color(255, 255, 255)]
number_bg = int(options['bg'])
text_color = [pygame.Color(0, 0, 0), pygame.Color(190, 190, 190), pygame.Color(255, 255, 255),
              pygame.Color(255, 0, 0), pygame.Color(255, 102, 0), pygame.Color(255, 255, 0),
              pygame.Color(0, 255, 0), pygame.Color(10, 80, 10), pygame.Color(0, 200, 200),
              pygame.Color(0, 0, 255), pygame.Color(75, 0, 130), pygame.Color(238, 130, 238),
              pygame.Color(160, 32, 240), pygame.Color(255, 0, 255), pygame.Color(120, 40, 45),
              pygame.Color(90, 90, 90)]
number_text_color = int(options['txt'])
button_color = [(pygame.Color(0, 0, 0), pygame.Color(50, 50, 50)),
                (pygame.Color(190, 190, 190), pygame.Color(220, 220, 220)),
                (pygame.Color(240, 240, 240), pygame.Color(255, 255, 255)),
                (pygame.Color(255, 0, 0), pygame.Color(255, 80, 80)),
                (pygame.Color(255, 102, 0), pygame.Color(255, 136, 56)),
                (pygame.Color(255, 255, 0), pygame.Color(255, 255, 130)),
                (pygame.Color(0, 255, 0), pygame.Color(120, 255, 120)),
                (pygame.Color(10, 80, 10), pygame.Color(0, 125, 0)),
                (pygame.Color(0, 200, 200), pygame.Color(30, 255, 255)),
                (pygame.Color(0, 0, 255), pygame.Color(80, 80, 255)),
                (pygame.Color(75, 0, 130), pygame.Color(125, 50, 180)),
                (pygame.Color(238, 130, 238), pygame.Color(255, 180, 255)),
                (pygame.Color(160, 32, 240), pygame.Color(210, 82, 255)),
                (pygame.Color(255, 0, 255), pygame.Color(255, 100, 255)),
                (pygame.Color(120, 40, 45), pygame.Color(155, 55, 60)),
                (pygame.Color(90, 90, 90), pygame.Color(127, 127, 127))]
number_button_color = int(options['btn'])
buttons = []
list_fig = [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]]
level = int(options['lvl'])
record = int(options['record'])
pause_scr = False
end_scr = False


def load_image(name, color_key=None):
    try:
        image = pygame.image.load(name)
    except pygame.error as message:
        print('Не удаётся загрузить:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if color_key is not None:
        if color_key is -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


class Board:
    global list_fig, level, record

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * height for _ in range(width)]
        self.left = 10
        self.top = 10
        self.cell_size = 30
        self.k = 0
        self.new_fig = False
        self.moving = False
        self.check_it = False
        self.end = False
        self.check_rotation = False
        self.x_pos = self.width // 2
        self.y_pos = 0
        self.clr = 0
        self.fig_coord = []
        self.new_fig_coord = []
        self.list_fig = list_fig[level]
        self.fl_full = True
        self.start = True
        self.create = False
        self.figs = []
        self.del_row = 0
        self.acc = 0
        self.record = record
        self.fil = ((pygame.Color(0, 0, 0)),
                    (pygame.Color(255, 0, 0), pygame.Color(255, 60, 60)),
                    (pygame.Color(255, 102, 0), pygame.Color(255, 136, 56)),
                    (pygame.Color(255, 255, 0), pygame.Color(255, 255, 130)),
                    (pygame.Color(0, 255, 0), pygame.Color(110, 255, 110)),
                    (pygame.Color(10, 80, 10), pygame.Color(0, 125, 0)),
                    (pygame.Color(0, 200, 200), pygame.Color(30, 255, 255)),
                    (pygame.Color(0, 0, 255), pygame.Color(60, 60, 255)),
                    (pygame.Color(75, 0, 130), pygame.Color(125, 50, 180)),
                    (pygame.Color(238, 130, 238), pygame.Color(255, 180, 255)),
                    (pygame.Color(160, 32, 240), pygame.Color(210, 82, 255)),
                    (pygame.Color(255, 0, 255), pygame.Color(255, 100, 255)),
                    (pygame.Color(120, 40, 45), pygame.Color(155, 55, 60)),
                    (pygame.Color(90, 90, 90), pygame.Color(127, 127, 127)))

    def render(self, screen):
        global record
        pygame.draw.rect(screen, text_color[number_text_color],
                         (self.left, self.top, self.cell_size * self.width,
                          self.cell_size * self.height), 2)
        for x in range(self.width):
            for y in range(self.height):
                if self.board[x][y] != 0:
                    pygame.draw.rect(screen, self.fil[self.board[x][y]][0],
                                     (x * self.cell_size + self.left,
                                      y * self.cell_size + self.top,
                                      self.cell_size - 0.5, self.cell_size - 0.5), 0, 5)
                    pygame.draw.rect(screen, self.fil[self.board[x][y]][1],
                                     (x * self.cell_size + self.left,
                                      y * self.cell_size + self.top,
                                      self.cell_size - 4, self.cell_size - 4), 0, 5)
                    pygame.draw.circle(screen, self.fil[self.board[x][y]][0],
                                       (x * self.cell_size + self.left + self.cell_size / 2 - 1,
                                        y * self.cell_size + self.top + self.cell_size / 2 - 1),
                                       self.cell_size / 2 - 8)
        font = pygame.font.SysFont('Times New Roman', 30)
        text = font.render(f'Очки   {self.del_row}', True, text_color[number_text_color])
        screen.blit(text, (180 - text.get_width(), 180))
        text2 = font.render(f'Скорость   {int(self.acc * 10)}', True, text_color[number_text_color])
        screen.blit(text2, (180 - text2.get_width(), 240))
        text3 = font.render(f'Рекорд   {self.record}', True, text_color[number_text_color])
        screen.blit(text3, (180 - text3.get_width(), 300))

        if self.end:
            self.record = max(self.record, self.del_row)
            options['record'] = self.record
            record = self.record
            self.save_opt()
            end_screen()

    def save_opt(self):
        f = open("tetris_options.txt", 'w', encoding="utf8")
        for key in options:
            f.write(f'{key}:{str(options[key])}\n')
        f.close()

    def render2(self, screen):
        for x in range(self.width):
            for y in range(self.height):
                if self.board[x][y] != 0:
                    pygame.draw.rect(screen, self.fil[self.board[x][y]][0],
                                     (x * self.cell_size + self.left,
                                      y * self.cell_size + self.top,
                                      self.cell_size - 0.5, self.cell_size - 0.5), 0, 5)
                    pygame.draw.rect(screen, self.fil[self.board[x][y]][1],
                                     (x * self.cell_size + self.left,
                                      y * self.cell_size + self.top,
                                      self.cell_size - 4, self.cell_size - 4), 0, 5)
                    pygame.draw.circle(screen, self.fil[self.board[x][y]][0],
                                       (x * self.cell_size + self.left + self.cell_size / 2 - 1,
                                        y * self.cell_size + self.top + self.cell_size / 2 - 1),
                                       self.cell_size / 2 - 8)
        font = pygame.font.SysFont('Times New Roman', 40)
        text = font.render('Следущая', True, text_color[number_text_color])
        screen.blit(text, (690, 110))
        text2 = font.render('фигура', True, text_color[number_text_color])
        screen.blit(text2, (720, 160))

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def draw_next(self, next_figure):
        if next_figure == 1:
            self.pre_coord = [(1, 0), (2, 0)]
        elif next_figure == 2:
            self.pre_coord = [(2, 0), (2, 1)]
        elif next_figure == 3:
            self.pre_coord = [(1, 0), (2, 0), (1, 1), (2, 1)]
        elif next_figure == 4:
            self.pre_coord = [(2, 0), (2, 1), (2, 2)]
        elif next_figure == 5:
            self.pre_coord = [(2, 0), (2, 1), (2, 2), (2, 3)]
        elif next_figure == 6:
            self.pre_coord = [(1, 0), (2, 0), (1, 1), (1, 2)]
        elif next_figure == 7:
            self.pre_coord = [(1, 0), (2, 0), (2, 1), (2, 2)]
        elif next_figure == 8:
            self.pre_coord = [(2, 0), (2, 1), (1, 1), (1, 2)]
        elif next_figure == 9:
            self.pre_coord = [(1, 0), (1, 1), (2, 1), (2, 2)]
        elif next_figure == 10:
            self.pre_coord = [(2, 0), (1, 1), (2, 1), (3, 1)]
        elif next_figure == 11:
            self.pre_coord = [(2, 0), (1, 1), (2, 1), (3, 1), (2, 2)]
        elif next_figure == 12:
            self.pre_coord = [(1, 0), (3, 0), (1, 1), (2, 1), (3, 1)]
        elif next_figure == 13:
            self.pre_coord = [(1, 0), (1, 1), (2, 1), (2, 2), (3, 2)]
        elif next_figure == 14:
            self.pre_coord = [(1, 0), (2, 0), (0, 1), (1, 1), (1, 2)]
        elif next_figure == 15:
            self.pre_coord = [(1, 0), (2, 0), (2, 1), (3, 1), (2, 2)]
        elif next_figure == 16:
            self.pre_coord = [(1, 0), (2, 0), (1, 1)]

    def draw_fig(self, figure):
        self.rot = 1
        self.rot2 = 0
        if figure == 1:
            self.fig_name = '1'
            self.fig_coord = [(self.width // 2 - 1, 0), (self.width // 2, 0)]
        elif figure == 2:
            self.fig_name = '2'
            self.fig_coord = [(self.width // 2, 0), (self.width // 2, 1)]
        elif figure == 3:
            self.fig_name = '3'
            self.fig_coord = [(self.width // 2, 0), (self.width // 2 - 1, 0),
                              (self.width // 2, 1), (self.width // 2 - 1, 1)]
        elif figure == 4:
            self.fig_name = '4'
            self.fig_coord = [(self.width // 2, 0), (self.width // 2, 1),
                              (self.width // 2, 2)]
        elif figure == 5:
            self.fig_name = '5'
            self.fig_coord = [(self.width // 2, 0), (self.width // 2, 1),
                              (self.width // 2, 2), (self.width // 2, 3)]
        elif figure == 6:
            self.fig_name = '6'
            self.fig_coord = [(self.width // 2 - 1, 0), (self.width // 2, 0),
                              (self.width // 2 - 1, 1), (self.width // 2 - 1, 2)]
        elif figure == 7:
            self.fig_name = '7'
            self.fig_coord = [(self.width // 2 - 1, 0), (self.width // 2, 0),
                              (self.width // 2, 1), (self.width // 2, 2)]
        elif figure == 8:
            self.fig_name = '8'
            self.fig_coord = [(self.width // 2, 0), (self.width // 2, 1),
                              (self.width // 2 - 1, 1), (self.width // 2 - 1, 2)]
        elif figure == 9:
            self.fig_name = '9'
            self.fig_coord = [(self.width // 2 - 1, 0), (self.width // 2 - 1, 1),
                              (self.width // 2, 1), (self.width // 2, 2)]
        elif figure == 10:
            self.fig_name = '10'
            self.fig_coord = [(self.width // 2, 1), (self.width // 2 - 1, 1),
                              (self.width // 2, 0), (self.width // 2 + 1, 1)]
        elif figure == 11:
            self.fig_name = '11'
            self.fig_coord = [(self.width // 2, 0), (self.width // 2 - 1, 1), (self.width // 2, 1),
                              (self.width // 2 + 1, 1), (self.width // 2, 2)]
        elif figure == 12:
            self.fig_name = '12'
            self.fig_coord = [(self.width // 2, 1), (self.width // 2 - 1, 0), (self.width // 2 + 1, 0),
                              (self.width // 2 - 1, 1), (self.width // 2 + 1, 1)]
        elif figure == 13:
            self.fig_name = '13'
            self.fig_coord = [(self.width // 2, 1), (self.width // 2 - 1, 1), (self.width // 2 - 1, 0),
                              (self.width // 2, 2), (self.width // 2 + 1, 2)]
        elif figure == 14:
            self.fig_name = '14'
            self.fig_coord = [(self.width // 2 - 1, 1), (self.width // 2 - 1, 0), (self.width // 2, 0),
                              (self.width // 2 - 2, 1), (self.width // 2 - 1, 2)]
        elif figure == 15:
            self.fig_name = '15'
            self.fig_coord = [(self.width // 2, 1), (self.width // 2 - 1, 0), (self.width // 2, 0),
                              (self.width // 2 + 1, 1), (self.width // 2, 2)]
        elif figure == 16:
            self.fig_name = '16'
            self.fig_coord = [(self.width // 2 - 1, 0), (self.width // 2, 0),
                              (self.width // 2 - 1, 1)]

    def create_new(self):
        if self.start:
            figure = choice(list_fig[level])
            self.clr = randint(1, 13)
            next_figure = choice(list_fig[level])
            self.next_clr = randint(1, 13)
            self.figs.append((figure, self.clr))
            self.figs.append((next_figure, self.next_clr))
            self.start = False
            return self.figs

        elif self.create:
            del self.figs[0]
            next_figure = choice(list_fig[level])
            self.next_clr = randint(1, 13)
            self.figs.append((next_figure, self.next_clr))
            self.create = False
            return self.figs

    def show_next(self, f_n, c_n):
        if not self.new_fig:
            for x in range(self.width):
                for y in range(self.height):
                    self.board[x][y] = 0
            next_figure = f_n
            self.draw_next(next_figure)
            self.next_clr = c_n
            for el in self.pre_coord:
                self.board[el[0]][el[1]] = self.next_clr

    def show_fig(self, f, c):
        if not self.new_fig:
            figure = f
            self.draw_fig(figure)
            for el in self.fig_coord:
                if self.board[el[0]][el[1]] != 0:
                    self.end = True
                    return
            self.clr = c
            for el in self.fig_coord:
                self.board[el[0]][el[1]] = self.clr
            self.new_fig = True
            self.moving = True
            self.create = True

    def move_fig(self):
        tmp_board = copy.deepcopy(self.board)
        for el in self.fig_coord:
            if el[1] == self.height - 1:
                self.moving = False
                self.check()
                self.new_fig = False
                return
            elif (el[0], el[1] + 1) not in self.fig_coord and self.board[el[0]][el[1] + 1] != 0:
                self.moving = False
                self.check()
                self.new_fig = False
                return
        if self.moving:
            self.new_fig_coord = []
            for el in self.fig_coord:
                tmp_board[el[0]][el[1]] = 0
                x, y = el[0], el[1] + 1
                self.new_fig_coord.append((x, y))
            for el in self.new_fig_coord:
                tmp_board[el[0]][el[1]] = self.clr
            self.board = copy.deepcopy(tmp_board)
            self.fig_coord = self.new_fig_coord

    def check(self):
        j = -1
        while j >= -self.height:
            for i in range(self.width):
                if self.board[i][j] == 0:
                    self.fl_full = False
                    j -= 1
                    break
                else:
                    self.fl_full = True
            if self.fl_full:
                tmp_board = copy.deepcopy(self.board)
                for x in range(self.width):
                    for y in range(self.height + j):
                        tmp_board[x][y + 1] = self.board[x][y]
                    tmp_board[x][0] = 0
                self.board = copy.deepcopy(tmp_board)
                self.del_row += 1
                if self.del_row > 0 and self.del_row % 10 == 0 and self.acc < 4:
                    self.acc += 0.5

    def l_click(self):
        tmp_board = copy.deepcopy(self.board)
        for el in self.fig_coord:
            if el[0] == 0:
                return
            elif (el[0] - 1, el[1]) not in self.fig_coord and self.board[el[0] - 1][el[1]] != 0:
                return
        if self.moving:
            self.new_fig_coord = []
            for el in self.fig_coord:
                tmp_board[el[0]][el[1]] = 0
                x, y = el[0] - 1, el[1]
                self.new_fig_coord.append((x, y))
            for el in self.new_fig_coord:
                tmp_board[el[0]][el[1]] = self.clr
            self.board = copy.deepcopy(tmp_board)
            self.fig_coord = self.new_fig_coord

    def r_click(self):
        tmp_board = copy.deepcopy(self.board)
        for el in self.fig_coord:
            if el[0] == self.width - 1:
                return
            elif (el[0] + 1, el[1]) not in self.fig_coord and self.board[el[0] + 1][el[1]] != 0:
                return
        if self.moving:
            self.new_fig_coord = []
            for el in self.fig_coord:
                tmp_board[el[0]][el[1]] = 0
                x, y = el[0] + 1, el[1]
                self.new_fig_coord.append((x, y))
            for el in self.new_fig_coord:
                tmp_board[el[0]][el[1]] = self.clr
            self.board = copy.deepcopy(tmp_board)
            self.fig_coord = self.new_fig_coord

    def rotate_click(self):
        if self.moving:
            self.check_rotation = True
            tmp_board = copy.deepcopy(self.board)
            self.new_fig_coord = []
            if self.fig_name == '1':
                self.rot2 = 0
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                self.new_fig_coord.append((self.fig_coord[1][0] - self.rot, self.fig_coord[1][1] + self.rot))
                self.rot *= -1
            elif self.fig_name == '2':
                self.rot2 = 0
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                self.new_fig_coord.append((self.fig_coord[1][0] - self.rot, self.fig_coord[1][1] - self.rot))
                self.rot *= -1
            elif self.fig_name == '3' or self.fig_name == '11':
                self.check_rotation = False
                return
            elif self.fig_name == '4':
                self.rot2 = 0
                self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1]))
                self.new_fig_coord.insert(0, (self.fig_coord[0][0] - self.rot, self.fig_coord[0][1] + self.rot))
                self.new_fig_coord.append((self.fig_coord[2][0] + self.rot, self.fig_coord[2][1] - self.rot))
                self.rot *= -1
            elif self.fig_name == '5':
                self.rot2 = 0
                self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1]))
                self.new_fig_coord.insert(0, (self.fig_coord[0][0] + self.rot, self.fig_coord[0][1] + self.rot))
                self.new_fig_coord.append((self.fig_coord[2][0] - self.rot, self.fig_coord[2][1] - self.rot))
                self.new_fig_coord.append((self.fig_coord[3][0] - 2 * self.rot, self.fig_coord[3][1] - 2 * self.rot))
                self.rot *= -1
            elif self.fig_name == '6':
                self.new_fig_coord.append((self.fig_coord[2][0], self.fig_coord[2][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.insert(0, (self.fig_coord[1][0], self.fig_coord[1][1] + 2 * self.rot))
                    self.new_fig_coord.insert(0, (self.fig_coord[0][0] + self.rot, self.fig_coord[0][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] - self.rot, self.fig_coord[3][1] - self.rot))
                else:
                    self.new_fig_coord.insert(0, (self.fig_coord[1][0] - 2 * self.rot, self.fig_coord[1][1]))
                    self.new_fig_coord.insert(0, (self.fig_coord[0][0] - self.rot, self.fig_coord[0][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] + self.rot, self.fig_coord[3][1] - self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '7':
                self.new_fig_coord.append((self.fig_coord[2][0], self.fig_coord[2][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.insert(0, (self.fig_coord[1][0] - self.rot, self.fig_coord[1][1] + self.rot))
                    self.new_fig_coord.insert(0, (self.fig_coord[0][0], self.fig_coord[0][1] + 2 * self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] + self.rot, self.fig_coord[3][1] - self.rot))
                else:
                    self.new_fig_coord.insert(0, (self.fig_coord[1][0] + self.rot, self.fig_coord[1][1] + self.rot))
                    self.new_fig_coord.insert(0, (self.fig_coord[0][0] + 2 * self.rot, self.fig_coord[0][1]))
                    self.new_fig_coord.append((self.fig_coord[3][0] - self.rot, self.fig_coord[3][1] - self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '8':
                self.rot2 = 0
                self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1]))
                self.new_fig_coord.insert(0, (self.fig_coord[0][0] - self.rot, self.fig_coord[0][1] + self.rot))
                self.new_fig_coord.append((self.fig_coord[2][0] + self.rot, self.fig_coord[2][1] + self.rot))
                self.new_fig_coord.append((self.fig_coord[3][0] + 2 * self.rot, self.fig_coord[3][1]))
                self.rot *= -1
            elif self.fig_name == '9':
                self.rot2 = 0
                self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1]))
                self.new_fig_coord.insert(0, (self.fig_coord[0][0] + self.rot, self.fig_coord[0][1] + self.rot))
                self.new_fig_coord.append((self.fig_coord[2][0] - self.rot, self.fig_coord[2][1] + self.rot))
                self.new_fig_coord.append((self.fig_coord[3][0] - 2 * self.rot, self.fig_coord[3][1]))
                self.rot *= -1
            elif self.fig_name == '10':
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.append((self.fig_coord[1][0] + self.rot, self.fig_coord[1][1] - self.rot))
                    self.new_fig_coord.append((self.fig_coord[2][0] + self.rot, self.fig_coord[2][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] - self.rot, self.fig_coord[3][1] + self.rot))
                else:
                    self.new_fig_coord.append((self.fig_coord[1][0] + self.rot, self.fig_coord[1][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[2][0] - self.rot, self.fig_coord[2][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] - self.rot, self.fig_coord[3][1] - self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '12':
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.append((self.fig_coord[1][0] + 2 * self.rot, self.fig_coord[1][1]))
                    self.new_fig_coord.append((self.fig_coord[2][0], self.fig_coord[2][1] + 2 * self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] + self.rot, self.fig_coord[3][1] - self.rot))
                    self.new_fig_coord.append((self.fig_coord[4][0] - self.rot, self.fig_coord[4][1] + self.rot))
                else:
                    self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1] + 2 * self.rot))
                    self.new_fig_coord.append((self.fig_coord[2][0] - 2 * self.rot, self.fig_coord[2][1]))
                    self.new_fig_coord.append((self.fig_coord[3][0] + self.rot, self.fig_coord[3][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[4][0] - self.rot, self.fig_coord[4][1] - self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '13':
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.append((self.fig_coord[1][0] + self.rot, self.fig_coord[1][1] - self.rot))
                    self.new_fig_coord.append((self.fig_coord[2][0] + 2 * self.rot, self.fig_coord[2][1]))
                    self.new_fig_coord.append((self.fig_coord[3][0] - self.rot, self.fig_coord[3][1] - self.rot))
                    self.new_fig_coord.append((self.fig_coord[4][0] - 2 * self.rot, self.fig_coord[4][1]))
                else:
                    self.new_fig_coord.append((self.fig_coord[1][0] + self.rot, self.fig_coord[1][1] + self.rot))
                    self.new_fig_coord.append((self.fig_coord[2][0], self.fig_coord[2][1] + 2 * self.rot))
                    self.new_fig_coord.append((self.fig_coord[3][0] + self.rot, self.fig_coord[3][1] - self.rot))
                    self.new_fig_coord.append((self.fig_coord[4][0], self.fig_coord[4][1] - 2 * self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '14':
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1]))
                self.new_fig_coord.append((self.fig_coord[3][0], self.fig_coord[3][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.insert(1, (self.fig_coord[2][0], self.fig_coord[2][1] + self.rot))
                    self.new_fig_coord.insert(2, (self.fig_coord[4][0] + self.rot, self.fig_coord[4][1]))
                else:
                    self.new_fig_coord.insert(1, (self.fig_coord[2][0] - self.rot, self.fig_coord[2][1]))
                    self.new_fig_coord.insert(2, (self.fig_coord[4][0], self.fig_coord[4][1] + self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '15':
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                self.new_fig_coord.append((self.fig_coord[2][0], self.fig_coord[2][1]))
                self.new_fig_coord.append((self.fig_coord[3][0], self.fig_coord[3][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.insert(1, (self.fig_coord[4][0] - self.rot, self.fig_coord[4][1]))
                    self.new_fig_coord.insert(2, (self.fig_coord[1][0], self.fig_coord[1][1] + self.rot))
                else:
                    self.new_fig_coord.insert(1, (self.fig_coord[4][0], self.fig_coord[4][1] + self.rot))
                    self.new_fig_coord.insert(2, (self.fig_coord[1][0] + self.rot, self.fig_coord[1][1]))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            elif self.fig_name == '16':
                self.new_fig_coord.append((self.fig_coord[1][0], self.fig_coord[1][1]))
                self.new_fig_coord.append((self.fig_coord[0][0], self.fig_coord[0][1]))
                if self.rot2 == 0:
                    self.new_fig_coord.insert(1, (self.fig_coord[2][0] + self.rot, self.fig_coord[2][1]))
                else:
                    self.new_fig_coord.insert(1, (self.fig_coord[2][0], self.fig_coord[2][1] + self.rot))
                    self.rot *= -1
                self.rot2 = (self.rot2 + 1) % 2
            for el in self.new_fig_coord:
                if el[0] < 0 or el[0] > self.width - 1 or el[1] < 0 or el[1] > self.height - 1:
                    self.check_rotation = False
                    if self.rot2 == 0:
                        self.rot *= -1
                    self.rot2 = (self.rot2 + 1) % 2
                    return
                elif (el[0], el[1]) not in self.fig_coord and self.board[el[0]][el[1]] != 0:
                    self.check_rotation = False
                    if self.rot2 == 0:
                        self.rot *= -1
                    self.rot2 = (self.rot2 + 1) % 2
                    return
            for el in self.fig_coord:
                tmp_board[el[0]][el[1]] = 0
            for el in self.new_fig_coord:
                tmp_board[el[0]][el[1]] = self.clr
            self.board = copy.deepcopy(tmp_board)
            self.fig_coord = self.new_fig_coord
            self.check_rotation = False


board = Board(15, 20)
board.set_view(220, 40, 30)
f_pre = Board(4, 4)
f_pre.set_view(720, 220, 30)


def terminate():
    global board
    board.save_opt()
    pygame.quit()
    sys.exit()


def start_screen():
    global screen, size, clock, fps, buttons

    button_1 = Button(15, 40, 160, 40, 'Настройки', screen, settings_screen)
    button_2 = Button(15, 90, 160, 40, 'Управление', screen, hotkeys)
    buttons.append(button_1)
    buttons.append(button_2)

    while True:
        screen.fill(bg_fil[number_bg])
        fon = load_image('tetr_fon.png', (255, 255, 255, 255))
        screen.blit(fon, (140, 255))
        font = pygame.font.SysFont('Times New Roman', 42)
        text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
        screen.blit(text, (50, 560))
        for i in range(2):
            buttons[i].process()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                return
        pygame.display.flip()
        clock.tick(fps)


def pause_screen():
    global screen, size, clock, text_color, fps, buttons, pause_scr
    pause_scr = True
    pause = pygame.Surface((880, 660), pygame.SRCALPHA)
    pause.fill((125, 125, 125, 125))
    screen.blit(pause, (0, 0))
    font = pygame.font.SysFont('Times New Roman', 42)
    text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
    screen.blit(text, (50, 560))
    while True:
        for i in range(2):
            buttons[i].process()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                pause_scr = False
                return
        pygame.display.flip()
        clock.tick(fps)


def end_screen():
    global board, f_pre, screen, size, clock, text_color, fps, buttons, end_scr
    end_scr = True
    end = pygame.Surface((880, 660), pygame.SRCALPHA)
    end.fill((125, 125, 125, 125))
    screen.blit(end, (0, 0))
    font = pygame.font.SysFont('Times New Roman', 52)
    text = font.render('ИГРА ОКОНЧЕНА', True, text_color[number_text_color])
    screen.blit(text, (230, 360))
    font = pygame.font.SysFont('Times New Roman', 42)
    text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
    screen.blit(text, (50, 560))
    while True:
        for i in range(2):
            buttons[i].process()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                board = Board(15, 20)
                board.set_view(220, 40, 30)
                f_pre = Board(4, 4)
                f_pre.set_view(720, 220, 30)
                end_scr = False
                return
        pygame.display.flip()
        clock.tick(fps)


def hotkeys():
    global screen, size, clock, fps, pause_scr, board, f_pre, end_scr
    fon = pygame.transform.scale(load_image('tetr_hotkeys.jpg'), size)
    screen.blit(fon, (0, 0))
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                if pause_scr:
                    screen.fill(bg_fil[number_bg])
                    board.render(screen)
                    f_pre.render2(screen)
                    pause = pygame.Surface((880, 660), pygame.SRCALPHA)
                    pause.fill((125, 125, 125, 125))
                    screen.blit(pause, (0, 0))
                    font = pygame.font.SysFont('Times New Roman', 42)
                    text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
                    screen.blit(text, (50, 560))
                if end_scr:
                    screen.fill(bg_fil[number_bg])
                    board.end = False
                    board.render(screen)
                    f_pre.render2(screen)
                    end = pygame.Surface((880, 660), pygame.SRCALPHA)
                    end.fill((125, 125, 125, 125))
                    screen.blit(end, (0, 0))
                    font = pygame.font.SysFont('Times New Roman', 52)
                    text = font.render('ИГРА ОКОНЧЕНА', True, text_color[number_text_color])
                    screen.blit(text, (230, 360))
                    font = pygame.font.SysFont('Times New Roman', 42)
                    text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
                    screen.blit(text, (50, 560))
                return
        pygame.display.flip()
        clock.tick(fps)


def settings_screen():
    global screen, clock, fps, bg_fil, number_bg, text_color, number_text_color, buttons, level, pause_scr, board
    global f_pre, end_scr
    screen.fill(bg_fil[number_bg])
    font = pygame.font.SysFont('Times New Roman', 50)
    text3 = font.render('Текст', True, text_color[number_text_color])
    screen.blit(text3, (670, 305))
    if level == 0:
        txt = 'Лёгкая'
    else:
        txt = 'Сложная'
    text4 = font.render(f'{txt}', True, text_color[number_text_color])
    screen.blit(text4, (670, 405))
    button_3 = Button(290, 100, 300, 50, 'Выберите фон', screen, background)
    button_4 = Button(290, 200, 300, 50, 'Выберите цвет кнопок', screen, button_clr)
    button_5 = Button(290, 300, 300, 50, 'Выберите цвет текста', screen, txt_clr)
    button_6 = Button(290, 400, 300, 50, 'Выберите сложность', screen, dfclt)
    buttons.extend([button_3, button_4, button_5, button_6])
    while True:
        screen.fill(bg_fil[number_bg])
        font = pygame.font.SysFont('Times New Roman', 50)
        text3 = font.render('Текст', True, text_color[number_text_color])
        screen.blit(text3, (90, 300))
        screen.blit(text3, (680, 300))
        if level == 0:
            txt = 'Лёгкая'
            text4_x = 70
        else:
            txt = 'Сложная'
            text4_x = 650
        text4 = font.render(f'{txt}', True, text_color[number_text_color])
        screen.blit(text4, (text4_x, 395))
        for i in range(2, 6):
            buttons[i].process()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if pause_scr:
                    screen.fill(bg_fil[number_bg])
                    board.render(screen)
                    f_pre.render2(screen)
                    pause = pygame.Surface((880, 660), pygame.SRCALPHA)
                    pause.fill((125, 125, 125, 125))
                    screen.blit(pause, (0, 0))
                    font = pygame.font.SysFont('Times New Roman', 42)
                    text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
                    screen.blit(text, (50, 560))
                if end_scr:
                    screen.fill(bg_fil[number_bg])
                    board.end = False
                    board.render(screen)
                    f_pre.render2(screen)
                    end = pygame.Surface((880, 660), pygame.SRCALPHA)
                    end.fill((125, 125, 125, 125))
                    screen.blit(end, (0, 0))
                    font = pygame.font.SysFont('Times New Roman', 52)
                    text = font.render('ИГРА ОКОНЧЕНА', True, text_color[number_text_color])
                    screen.blit(text, (230, 360))
                    font = pygame.font.SysFont('Times New Roman', 42)
                    text = font.render('Для продолжения нажмите любую клавишу', True, text_color[number_text_color])
                    screen.blit(text, (50, 560))
                return
        pygame.display.flip()
        clock.tick(fps)


def background():
    global number_bg, number_text_color, number_button_color, options
    number_bg = (number_bg + 1) % 3
    options['bg'] = number_bg
    if number_text_color == number_bg:
        number_text_color = (number_bg + 1) % 3
        options['txt'] = number_text_color
    if number_button_color == number_bg:
        number_button_color = (number_bg + 1) % 3
        options['btn'] = number_button_color


def button_clr():
    global number_bg, number_button_color, options
    number_button_color = (number_button_color + 1) % 16
    if number_button_color == number_bg:
        number_button_color += 1
    options['btn'] = number_button_color


def txt_clr():
    global number_bg, number_text_color, options
    number_text_color = (number_text_color + 1) % 16
    if number_text_color == number_bg:
        number_text_color += 1
    options['txt'] = number_text_color


def dfclt():
    global level, options
    level = (level + 1) % 2
    options['lvl'] = level


class Button:
    global bg_fil, number_bg, button_color, number_button_color

    def __init__(self, x, y, width, height, button_text, screen, function=None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.function = function
        self.screen = screen
        self.button_text = button_text
        self.button_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.button_rect2 = pygame.Rect(self.x + 1, self.y + 1, self.width - 5, self.height - 5)
        self.already_pressed = False

    def process(self):
        self.fill_colors = {
            'normal': button_color[number_button_color][1],
            'hover': button_color[number_button_color][0],
            'pressed': bg_fil[number_bg]
        }
        self.font = pygame.font.SysFont('Times New Roman', 30)
        self.btn_txt = self.font.render(self.button_text, True, bg_fil[number_bg])
        fil = self.fill_colors['normal']
        fil2 = self.fill_colors['hover']
        mouse_pos = pygame.mouse.get_pos()
        if self.button_rect.collidepoint(mouse_pos):
            fil = self.fill_colors['hover']
            fil2 = self.fill_colors['normal']
            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                fil = self.fill_colors['pressed']
                fil2 = self.fill_colors['pressed']
                if not self.already_pressed:
                    self.function()
                    self.already_pressed = True
            else:
                self.already_pressed = False
        pygame.draw.rect(self.screen, fil, self.button_rect, 0, 5)
        pygame.draw.rect(self.screen, fil2, self.button_rect2, 0, 5)
        self.screen.blit(self.btn_txt, (self.x + self.button_rect.width / 2 - self.btn_txt.get_width() / 2,
                                        self.y + self.button_rect.height / 2 - self.btn_txt.get_height() / 2))


def main():
    global board, f_pre, screen, clock, fps, bg_fil, number_bg

    start_screen()
    speed = 60
    ticks = 0

    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 or
                    event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT):
                board.l_click()
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 3 or
                    event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT):
                board.r_click()
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 4 or
                    event.type == pygame.KEYDOWN and event.key == pygame.K_UP):
                if not board.check_rotation:
                    board.rotate_click()
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 5 or
                    event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN):
                if not board.check_rotation:
                    speed = 0
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pause_screen()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                board.move_fig()
        screen.fill(bg_fil[number_bg])
        board.render(screen)
        f_pre.render2(screen)
        board.create_new()
        f, c = board.figs[0][0], board.figs[0][1]
        f_n, c_n = board.figs[0][0], board.figs[0][1]
        f_pre.show_next(f_n, c_n)
        board.show_fig(f, c)
        if board.moving:
            if ticks >= speed:
                board.move_fig()
                ticks = 0
                speed = 60 - board.acc * 10
        pygame.display.flip()
        clock.tick(fps)
        ticks += 1
    board.save_opt()
    pygame.quit()


if __name__ == '__main__':
    main()
